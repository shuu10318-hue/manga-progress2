/* Fillio — existing project settings/edit module */
// --- 工程カスタマイズ ---
let stageDraft=[];
let stageDraftMeta=[];
function escapeStageHtml(s){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function initStageDraft(p){
  const arr=Array.isArray(p?.stages)&&p.stages.length?p.stages:DEFAULT_STAGES;
  stageDraft=cloneStages(arr);
  stageDraftMeta=arr.map((_,i)=>({originalIndex:i}));
}
function renderStageEditor(){
 const box=document.getElementById("stageEditorList"); if(!box)return; box.innerHTML="";
 stageDraft.forEach((stage,i)=>box.appendChild(makeStageRow(stage,i,stageDraft,renderStageEditor,stageDraftMeta)));
 const add=document.getElementById("stageAddButton");if(add)add.disabled=false;
}
document.getElementById("stageAddButton")?.addEventListener("click",()=>{
  if(stageDraft.length>=MAX_STAGES){alert(t("stage.max",{max:MAX_STAGES}));return}
  stageDraft.push({name:""});
  stageDraftMeta.push({originalIndex:null});
  renderStageEditor();
});

document.getElementById("clearEditProjectDeadline")?.addEventListener("click",()=>{
  document.getElementById("editProjectDeadline").value="";
});

let editingProjectId=null;
function openProjectEdit(id){
  const p=projectStore.projects[id]; if(!p)return;
  editingProjectId=id;
  initStageDraft(p);
  renderStageEditor();
  document.getElementById("editProjectTitle").value=p.title||"";
  document.getElementById("editProjectPages").value=Math.min(PROJECT_PAGE_MAX,p.totalPages||1);
  document.getElementById("editProjectCreationStartDate").value=p.creationStartDate||"";
  document.getElementById("editProjectDeadline").value=p.deadline||"";
  document.getElementById("editProjectModal").classList.add("open");
  document.body.style.overflow="hidden";
}
function closeProjectEdit(){
  document.getElementById("editProjectModal").classList.remove("open");
  document.body.style.overflow="";
  editingProjectId=null;
}

document.getElementById("cancelEditProject").addEventListener("click",closeProjectEdit);
document.getElementById("editProjectModal").addEventListener("click",e=>{if(e.target.id==="editProjectModal")closeProjectEdit();});
document.getElementById("saveEditProject").addEventListener("click",()=>{
  if(!editingProjectId)return;
  const p=projectStore.projects[editingProjectId];
  const newTotal=clampPageCount(document.getElementById("editProjectPages").value);
  const oldProgress=Array.isArray(p.progress)?p.progress:[];
  const oldStages=Array.isArray(p.stages)&&p.stages.length?cloneStages(p.stages):cloneStages(DEFAULT_STAGES);
  const cleanedStages=stageDraft.map(normalizeStage);
  // Each draft item carries its original column index, so rename/reorder preserves the exact progress column.
  const mapping=stageDraftMeta.map(x=>x.originalIndex);
  p.stages=cleanedStages;
  p.progress=Array.from({length:newTotal},(_,i)=>{
    if(i>=oldProgress.length)return Array(p.stages.length).fill(0);
    const oldRow=oldProgress[i]||[];
    return mapping.map(oi=>oi===null?0:(oldRow[oi]??0));
  });
  p.title=document.getElementById("editProjectTitle").value.trim();
  p.totalPages=newTotal;
  p.creationStartDate=document.getElementById("editProjectCreationStartDate").value||p.creationStartDate||localDate();
  p.deadline=document.getElementById("editProjectDeadline").value||"";
  // Keep the Library context that was active when this settings sheet was opened.
  // renderProjectList() rebuilds every project card, so the folder filter must be
  // reapplied explicitly after saving; otherwise a folder view temporarily looks
  // like the Library root.
  const returnFolderId=currentFolderId;
  persistProjectStore();
  closeProjectEdit();
  renderProjectList();
  currentFolderId=(returnFolderId&&projectStore.folders?.[returnFolderId])?returnFolderId:null;
  renderFoldersAndFilter();
  saveViewState(currentFolderId?"folder":"root");
  syncFillioHistory("replace");
});


const editOverlay=document.getElementById("editProjectModal");
["touchstart","touchmove","touchend"].forEach(type=>{
  editOverlay.addEventListener(type,e=>e.stopPropagation(),{passive:true});
});
